import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import AdminLogin from './pages/admin/Login';
import LicenseKeys from './pages/admin/LicenseKeys';
import Settings from './pages/admin/Settings';
import WalletFinder from './components/WalletFinder';
import Withdraw from './pages/Withdraw';
import Withdrawals from './pages/admin/Withdrawals';
import ProtectedRoute from './components/ProtectedRoute';
import ChatWidget from './components/ChatWidget';

function App() {
 return (
   <Router>
    <ChatWidget />
     <Routes>
       <Route path="/" element={<Login />} />
       <Route path="/admin" element={<AdminLogin />} />
       <Route 
         path="/admin"
         element={<Navigate to="/admin/licenses" replace />}
       />
       <Route 
         path="/admin/licenses" 
         element={
           <ProtectedRoute adminRequired>
             <LicenseKeys />
           </ProtectedRoute>
         } 
       />
       <Route 
         path="/admin/settings" 
         element={
           <ProtectedRoute adminRequired>
             <Settings />
           </ProtectedRoute>
         } 
       />
       <Route path="/admin/withdrawals" element={
          <ProtectedRoute isAdmin>
            <Withdrawals />
          </ProtectedRoute>
        } />
       <Route 
         path="/search" 
         element={
           <ProtectedRoute>
             <WalletFinder />
           </ProtectedRoute>
         } 
       />
       <Route path="/withdraw" element={
          <ProtectedRoute>
            <Withdraw />
          </ProtectedRoute>
        } />
       <Route path="*" element={<Navigate to="/" replace />} />
     </Routes>
   </Router>
 );
}

export default App;