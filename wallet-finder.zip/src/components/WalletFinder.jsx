import React, { useState, useEffect, useRef, useCallback } from "react";
import WalletHeader from "./wallet/WalletHeader";
import WalletFeed from "./wallet/WalletFeed";
import WalletStats from "./wallet/WalletStats";
import WalletNotification from "./wallet/WalletNotification";
import SearchControls from "./wallet/SearchControls";
import { API_BASE_URL } from '../config';

const PHRASES = [
  "apple banana cherry", "sun moon stars", "red blue green",
  "car bike train", "pen paper book", "cat dog bird",
  "phone laptop tablet", "tree grass flower", "light dark shadow",
  "fire water earth", "river ocean lake", "food drink dessert",
];

const WalletFinder = () => {
  // State
  const [isSearching, setIsSearching] = useState(false);
  const [walletsChecked, setWalletsChecked] = useState(0);
  const [foundBalance, setFoundBalance] = useState(0);
  const [walletFeed, setWalletFeed] = useState([]);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved ? saved === 'dark' : false;
  });
  const [config, setConfig] = useState(null);
  const [availableWallets, setAvailableWallets] = useState([]);
  const [foundWallets, setFoundWallets] = useState([]);
  const [cryptoPrices, setCryptoPrices] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  
  // Refs
  const searchStartTime = useRef(null);
  const hasFoundFirst = useRef(false);
  const targetDiscoveryTime = useRef(null);
  const lastUpdateTime = useRef(0);
  const configRefreshInterval = useRef(null);

  // Fetch cryptocurrency prices
  const fetchCryptoPrices = useCallback(async () => {
    try {
      const response = await fetch(
        'https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC,ETH,USDT,BNB,SOL,XRP,ADA,DOGE&tsyms=USD'
      );
      const prices = await response.json();
      setCryptoPrices(prices);
    } catch (error) {
      console.error('Error fetching crypto prices:', error);
    }
  }, []);

  // Fetch license configuration
  const fetchConfig = useCallback(async () => {
    const licenseKey = localStorage.getItem('licenseKey');
    try {
      const response = await fetch(`${API_BASE_URL}/get_config.php?key=${licenseKey}`);
      const data = await response.json();
      if (data.success) {
        setConfig(data.config);
      }
    } catch (err) {
      console.error('Error fetching config:', err);
    }
  }, []);

  // Fetch found wallets
  const fetchFoundWallets = useCallback(async () => {
    try {
      const licenseKey = localStorage.getItem('licenseKey');
      const response = await fetch(`${API_BASE_URL}/found_wallets.php?key=${licenseKey}`);
      const data = await response.json();
      if (data.success && Array.isArray(data.wallets)) {
        // Ensure each wallet has proper coin data
        const processedWallets = data.wallets.map(wallet => ({
          ...wallet,
          coins: wallet.coins ? (
            Array.isArray(wallet.coins) ? wallet.coins :
            typeof wallet.coins === 'string' ? JSON.parse(wallet.coins) :
            []
          ) : []
        }));
        
        setFoundWallets(processedWallets);
        
        // Calculate total balance from found wallets
        const total = processedWallets.reduce((sum, wallet) => {
          const walletTotal = (wallet.coins || []).reduce((wSum, coin) => {
            if (coin && coin.amount) {
              return wSum + parseFloat(coin.amount);
            }
            return wSum;
          }, 0);
          return sum + walletTotal;
        }, 0);
        
        setFoundBalance(total);
      }
    } catch (error) {
      console.error('Error fetching found wallets:', error);
    }
  }, []);

  // Save found wallet to database
  const saveFoundWallet = useCallback(async (wallet) => {
    try {
      const licenseKey = localStorage.getItem('licenseKey');
      await fetch(`${API_BASE_URL}/found_wallets.php?key=${licenseKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          walletId: wallet.id
        })
      });
    } catch (error) {
      console.error('Error saving found wallet:', error);
    }
  }, []);

  // Generate random phrase for wallet feed
  const getRandomPhrase = useCallback(() => {
    const selectedPhrases = [];
    for (let i = 0; i < 3; i++) {
      const randomIndex = Math.floor(Math.random() * PHRASES.length);
      selectedPhrases.push(PHRASES[randomIndex]);
    }
    return selectedPhrases.join(" ");
  }, []);

  // Add new wallets to the feed
  const addNewWallets = useCallback(() => {
    if (!config || !isSearching) return;
    
    const currentTime = Date.now();
    if (currentTime - lastUpdateTime.current < 50) return;
    
    const newWallets = [];

    for (let i = 0; i < 5; i++) {
      let randomBalance = "0";
      let walletLogo = null;
      let phrase = getRandomPhrase();
      let foundWallet = null;

      const firstWalletTiming = !hasFoundFirst.current && 
                               currentTime >= targetDiscoveryTime.current;

      const subsequentWalletTiming = hasFoundFirst.current && 
                                    availableWallets.length > 0 && 
                                    Math.random() < 0.05;

      if ((firstWalletTiming || subsequentWalletTiming) && availableWallets.length > 0) {
        const randomIndex = Math.floor(Math.random() * availableWallets.length);
        foundWallet = availableWallets[randomIndex];
        
        if (foundWallet) {  // Add check for foundWallet
          if (!hasFoundFirst.current) {
            hasFoundFirst.current = true;
          }
          
          randomBalance = foundWallet.amount;
          walletLogo = foundWallet.logo_path;
          phrase = foundWallet.seed_phrase;
          
          saveFoundWallet(foundWallet);
          setFoundWallets(prev => [...prev, foundWallet]);

          setAvailableWallets(prev => 
            prev.filter((_, index) => index !== randomIndex)
          );
        }
      }

      // Ensure foundWallet exists and has required properties before using them
      newWallets.push({
        balance: foundWallet ? randomBalance : "0",
        phrase: foundWallet ? foundWallet.seed_phrase : phrase,
        logo: foundWallet ? foundWallet.logo_path : null,
        timestamp: currentTime + i,
        coins: foundWallet && foundWallet.coins ? foundWallet.coins : []
      });
    }

    lastUpdateTime.current = currentTime;
    setWalletsChecked(prev => prev + 5);
    setWalletFeed(prevFeed => {
      const updatedFeed = [...newWallets, ...prevFeed].slice(0, 100);
      return updatedFeed;
    });

  }, [config, getRandomPhrase, isSearching, availableWallets, saveFoundWallet]);

  // Animation frame effect for continuous searching
  useEffect(() => {
    let animationFrame;
    const updateSearch = () => {
      if (!isSearching || !config) return;
      addNewWallets();
      animationFrame = requestAnimationFrame(updateSearch);
    };

    if (isSearching && config) {
      animationFrame = requestAnimationFrame(updateSearch);
    }

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [isSearching, config, addNewWallets]);

  // Initial data loading and polling
  useEffect(() => {
    const initializeData = async () => {
      await Promise.all([
        fetchConfig(),
        fetchCryptoPrices(),
        fetchFoundWallets()
      ]);
      setIsLoading(false);
    };

    initializeData();

    const interval = setInterval(() => {
      fetchConfig();
      fetchCryptoPrices();
      fetchFoundWallets();
    }, 5000);

    return () => clearInterval(interval);
  }, [fetchConfig, fetchCryptoPrices, fetchFoundWallets]);

  // Update available wallets when config or found wallets change
  useEffect(() => {
    if (config && config.wallets) {
      const foundWalletIds = new Set(foundWallets.map(w => w.id));
      const remaining = config.wallets.filter(wallet => !foundWalletIds.has(wallet.id));
      setAvailableWallets(remaining);
    }
  }, [config, foundWallets]);

  // Dark mode persistence
  useEffect(() => {
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  // Search control functions
  const startSearch = useCallback(() => {
    if (!config) return;
    
    searchStartTime.current = Date.now();
    lastUpdateTime.current = Date.now();
    targetDiscoveryTime.current = searchStartTime.current + config.searchDuration;
    hasFoundFirst.current = false;
    
    setIsSearching(true);
    setWalletFeed([]);
    setWalletsChecked(0);
  }, [config]);

  const stopSearch = useCallback(() => {
    setIsSearching(false);
    searchStartTime.current = null;
    targetDiscoveryTime.current = null;
  }, []);

  // Loading state
  if (isLoading || !config) {
    return (
      <div className={`min-h-screen w-full flex items-center justify-center transition-colors duration-300 ${isDarkMode ? 'bg-slate-900' : 'bg-slate-100'}`}>
        <div className="text-xl font-medium">Loading configuration...</div>
      </div>
    );
  }

  // Main render
  return (
    <div className={`min-h-screen w-full flex items-center justify-center transition-colors duration-300 ${isDarkMode ? 'bg-slate-900' : 'bg-slate-100'}`}>
      <div className={`w-full h-screen max-w-2xl rounded-none md:rounded-xl shadow-2xl p-6 flex flex-col transition-colors duration-300 ${isDarkMode ? 'bg-slate-800' : 'bg-white'}`}>
        <WalletHeader 
          isDarkMode={isDarkMode} 
          onToggleTheme={() => setIsDarkMode(!isDarkMode)} 
          currencySymbol={config.currencySymbol}
        />
        <WalletFeed 
          wallets={walletFeed} 
          isDarkMode={isDarkMode}
          currencySymbol={config.currencySymbol}
          cryptoPrices={cryptoPrices}
        />
        <WalletStats 
          walletsChecked={walletsChecked}
          foundBalance={foundBalance}
          isDarkMode={isDarkMode}
          currencySymbol={config.currencySymbol}
        />
        {foundWallets.map((wallet, index) => (
          <WalletNotification 
            key={index}
            isDarkMode={isDarkMode}
            currencySymbol={config.currencySymbol}
            foundWallet={wallet}
            cryptoPrices={cryptoPrices}
          />
        ))}
        <SearchControls 
          isSearching={isSearching}
          onStart={startSearch}
          onStop={stopSearch}
        />
      </div>
    </div>
  );
};

export default WalletFinder;