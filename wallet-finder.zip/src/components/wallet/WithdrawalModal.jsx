import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { Copy, Loader2, MessagesSquare } from 'lucide-react';
import { API_BASE_URL } from '../../config';

const WithdrawalModal = ({ 
  isOpen, 
  onClose, 
  wallet, 
  coin,
  isDarkMode 
}) => {
  const [withdrawalAddress, setWithdrawalAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [paymentDisplay, setPaymentDisplay] = useState(null);
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    const fetchPaymentDisplay = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/get_payment_settings.php`);
        const data = await response.json();
        if (data.success) {
          setPaymentDisplay(data);
        }
      } catch (error) {
        console.error('Error fetching payment display:', error);
      }
    };

    if (isOpen) {
      fetchPaymentDisplay();
    }
  }, [isOpen]);

  const handleCopyAddress = async () => {
    if (paymentDisplay?.wallet_address) {
      try {
        await navigator.clipboard.writeText(paymentDisplay.wallet_address);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      } catch (error) {
        console.error('Failed to copy:', error);
      }
    }
  };

  const handleOpenChat = () => {
    // Open Chaport chat if available
    if (window.chaport) {
      window.chaport.open();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsSubmitting(true);

    try {
      const licenseKey = localStorage.getItem('licenseKey');
      const response = await fetch(`${API_BASE_URL}/submit_withdrawal.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          licenseKey,
          walletId: wallet.id,
          coinSymbol: coin.symbol,
          withdrawalAddress,
          amount: coin.amount
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setSuccess('Withdrawal request submitted successfully!');
        setTimeout(() => {
          onClose(true);
        }, 2000);
      } else {
        setError(data.error || 'Failed to submit withdrawal request');
      }
    } catch (error) {
      setError('Failed to submit withdrawal request');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose(false)}>
      <DialogContent className={`sm:max-w-[425px] ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-white'}`}>
        <DialogHeader>
          <DialogTitle>Withdraw {coin.symbol}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Payment Details Section */}
          {paymentDisplay && (
            <div className={`p-4 rounded-lg ${
              isDarkMode ? 'bg-slate-700' : 'bg-gray-50'
            }`}>
              <div className="mb-4">
                <h3 className="font-medium mb-2 text-center">Payment Required</h3>
                <p className="text-sm text-center text-gray-500 dark:text-gray-400">
                  Please contact admin via chat to know the fee amount before proceeding.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={paymentDisplay.wallet_address}
                    readOnly
                    className={`flex-1 p-2 rounded-lg font-mono text-sm ${
                      isDarkMode 
                        ? 'bg-slate-800 border-slate-600' 
                        : 'bg-white border-gray-200'
                    } border`}
                    aria-label="Payment wallet address"
                  />
                  <button
                    type="button"
                    onClick={handleCopyAddress}
                    className={`p-2 rounded-lg transition-colors ${
                      isDarkMode 
                        ? 'hover:bg-slate-600' 
                        : 'hover:bg-gray-200'
                    }`}
                    aria-label="Copy address"
                  >
                    {copySuccess ? 'Copied!' : <Copy size={16} />}
                  </button>
                </div>

                <div className="text-center text-sm text-gray-500 dark:text-gray-400">
                  Only send {paymentDisplay.coin_type} to this address. 
                  Sending any other coins will result in permanent loss.
                </div>

                <button
                  type="button"
                  onClick={handleOpenChat}
                  className="w-full flex items-center justify-center gap-2 p-2 text-blue-600 hover:text-blue-700 transition-colors rounded-lg hover:bg-blue-50 dark:hover:bg-slate-700"
                >
                  <MessagesSquare size={16} />
                  <span>Contact Admin via Chat</span>
                </button>
              </div>
            </div>
          )}

          {/* Withdrawal Form */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Your {coin.symbol} Withdrawal Address
            </label>
            <input
              type="text"
              value={withdrawalAddress}
              onChange={(e) => setWithdrawalAddress(e.target.value)}
              className={`w-full p-2 rounded-lg border ${
                isDarkMode 
                  ? 'bg-slate-700 border-slate-600' 
                  : 'bg-white border-gray-300'
              }`}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Amount to Withdraw
            </label>
            <div className={`p-2 rounded-lg ${
              isDarkMode ? 'bg-slate-700' : 'bg-gray-100'
            }`}>
              {coin.amount} {coin.symbol}
            </div>
          </div>

          {/* Error/Success Messages */}
          {error && (
            <div className="p-2 rounded-lg bg-red-100 text-red-600 text-sm">
              {error}
            </div>
          )}
          {success && (
            <div className="p-2 rounded-lg bg-green-100 text-green-600 text-sm">
              {success}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-2 rounded-lg transition-colors ${
              isDarkMode 
                ? 'bg-blue-500 hover:bg-blue-600' 
                : 'bg-blue-600 hover:bg-blue-700'
            } text-white disabled:opacity-50`}
          >
            {isSubmitting ? (
              <Loader2 className="w-5 h-5 animate-spin mx-auto" />
            ) : (
              'Submit Withdrawal Request'
            )}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default WithdrawalModal;