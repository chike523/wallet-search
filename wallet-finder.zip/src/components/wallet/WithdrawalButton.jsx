import React from 'react';
import { Clock, X } from 'lucide-react';

const WithdrawalButton = ({ coin, status, onClick }) => {
  console.log('Button status:', status); // Debug log

  let buttonStyle = '';
  let buttonContent = null;
  let isDisabled = false;

  switch(status) {
    case 'pending':
      buttonStyle = 'bg-yellow-500 hover:bg-yellow-600';
      buttonContent = (
        <>
          <Clock size={16} className="mr-2" />
          Pending
        </>
      );
      isDisabled = true;
      break;
    case 'rejected':
      buttonStyle = 'bg-red-500 hover:bg-red-600';
      buttonContent = (
        <>
          <X size={16} className="mr-2" />
          Retry Withdrawal
        </>
      );
      isDisabled = false;
      break;
    default:
      buttonStyle = 'bg-blue-500 hover:bg-blue-600';
      buttonContent = `Withdraw ${coin.symbol}`;
      isDisabled = false;
  }

  return (
    <button
      onClick={onClick}
      disabled={isDisabled}
      className={`px-4 py-2 rounded-lg transition-colors text-white flex items-center justify-center ${buttonStyle} ${
        isDisabled ? 'opacity-50 cursor-not-allowed' : ''
      }`}
    >
      {buttonContent}
    </button>
  );
};

export default WithdrawalButton;