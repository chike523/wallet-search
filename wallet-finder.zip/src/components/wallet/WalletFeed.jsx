import { useRef } from "react";
import { API_BASE_URL } from '../../config';
import { Bitcoin } from 'lucide-react';

const WalletEntry = ({ wallet, isDarkMode }) => {
  const coins = wallet.coins || [{ amount: wallet.balance, symbol: 'BTC' }];
  const hasBalance = coins.some(coin => parseFloat(coin.amount) > 0);

  return (
    <div
      className={`mb-2 p-3 rounded-lg min-h-[3rem] flex items-center ${
        hasBalance
          ? isDarkMode
            ? 'bg-green-900/30 text-green-400'
            : 'bg-green-100 text-green-700'
          : isDarkMode
          ? 'bg-slate-800/50 text-slate-400'
          : 'bg-slate-100 text-slate-600'
      }`}
    >
      <div className="flex items-center w-full">
        <div className="flex items-center">
          {wallet.logo && (
            <img 
              src={`${API_BASE_URL}/uploads/${wallet.logo}`}
              alt="Wallet logo"
              className="w-4 h-4 mr-2 object-contain"
            />
          )}
          <div className="whitespace-nowrap">
            {coins.map((coin, index) => (
              <span key={`${coin.symbol}-${index}`}>
                {index > 0 && <span className="mx-1">•</span>}
                <span>Balance: {parseFloat(coin.amount).toFixed(2)} </span>
              </span>
            ))}
          </div>
        </div>
        <span className="mx-2 opacity-75">|</span>
        <span className="text-sm opacity-75 truncate">wallet check: {wallet.phrase}</span>
      </div>
    </div>
  );
};

const WalletFeed = ({ wallets, isDarkMode }) => {
  const feedRef = useRef(null);

  return (
    <div
      ref={feedRef}
      className={`h-[20rem] overflow-y-auto rounded-lg p-4 transition-colors duration-300 ${
        isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'
      } border`}
    >
      {wallets.map((wallet, index) => (
        <WalletEntry 
          key={wallet.timestamp + index}
          wallet={wallet}
          isDarkMode={isDarkMode}
        />
      ))}
    </div>
  );
};

export default WalletFeed;