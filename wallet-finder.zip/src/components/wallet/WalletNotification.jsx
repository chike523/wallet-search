import { API_BASE_URL } from '../../config';

const WalletNotification = ({ isDarkMode, currencySymbol, foundWallet, cryptoPrices }) => {
  if (!foundWallet || !cryptoPrices) return null;

  // Debug logging
  console.log('Wallet data:', foundWallet);
  
  return (
    <div className={`mb-3 px-4 py-2.5 flex items-center gap-3 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
      {foundWallet.logo_path && (
        <img 
          src={`${API_BASE_URL}/uploads/${foundWallet.logo_path}`}
          alt="Wallet logo"
          className="w-5 h-5 object-contain"
        />
      )}
      <div className="flex-1 whitespace-nowrap overflow-hidden">
        {foundWallet.coins && foundWallet.coins.map((coin, index) => {
          if (!coin || !coin.symbol || !coin.amount) return null;
          
          const price = cryptoPrices[coin.symbol]?.USD || 0;
          const cryptoAmount = price ? parseFloat(coin.amount) / price : 0;
          
          return (
            <span key={`${coin.symbol}-${index}`}>
              {index > 0 && <span className="mx-2 opacity-50">•</span>}
              <span className="font-medium">
                {cryptoAmount.toFixed(8)} {coin.symbol}
                <span className="ml-1 opacity-75">
                  ({currencySymbol}{parseFloat(coin.amount).toFixed(2)})
                </span>
              </span>
            </span>
          );
        })}
        {foundWallet.seed_phrase && (
          <>
            <span className="mx-2 opacity-50">•</span>
            <span className="text-sm opacity-60 truncate after:content-['...']">
              {foundWallet.seed_phrase}
            </span>
          </>
        )}
      </div>
    </div>
  );
};

export default WalletNotification;