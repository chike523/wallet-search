import { useEffect } from 'react';

const ChatWidget = () => {
  useEffect(() => {
    // Initialize Chaport
    window.chaportConfig = {
      appId: '6798f77c73a4ef82623f009a'
    };

    if (!window.chaport) {
      const v3 = window.chaport = {};
      v3._q = [];
      v3._l = {};
      v3.q = function() { v3._q.push(arguments) };
      v3.on = function(e, fn) {
        if (!v3._l[e]) v3._l[e] = [];
        v3._l[e].push(fn);
      };
      
      const s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = 'https://app.chaport.com/javascripts/insert.js';
      const ss = document.getElementsByTagName('script')[0];
      ss.parentNode.insertBefore(s, ss);
    }
  }, []);

  return null; // This component doesn't render anything
};

export default ChatWidget;