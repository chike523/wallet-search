// src/config.js

// Local development
export const API_BASE_URL = 'https://cryptowhales-software.com/api';

// When deploying, change this to your shared hosting URL
// export const API_BASE_URL = 'https://yourdomain.com/wallet-finder/api';